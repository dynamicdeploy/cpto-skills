# CPTO Due Diligence Report: [COMPANY NAME] — [PRODUCT NAME]

**Report Date:** [DATE]
**Prepared By:** CPTO Due Diligence Skill
**Assessment Context:** [M&A / Partnership / Investment / Internal Audit]
**Confidentiality:** [CONFIDENTIAL — Authorized Personnel Only]

---

## EXECUTIVE SUMMARY

| Dimension | Score (1–5) | Risk Level |
|---|---|---|
| Product & Market Fit | | |
| Technical Architecture | | |
| Application Security | | |
| AI & Innovation | | |
| Business Operations | | |
| Engineering Velocity | | |
| **OVERALL** | | |

**Recommendation:** ☐ Proceed   ☐ Proceed with Conditions   ☐ Do Not Proceed

**One-Paragraph Summary:**
[2–4 sentence executive-level judgment covering the most important finding, the biggest risk, and the recommendation rationale]

**Top 3 Strengths:**
1. 
2. 
3. 

**Top 3 Concerns:**
1. 
2. 
3. 

**Deal-Breaker Flags:** [None / List any]

---

## SECTION 1 — COMPANY & PRODUCT OVERVIEW

### 1.1 Company Profile
- **Company Name:**
- **Founded:**
- **HQ Location:**
- **Stage / Funding:**
- **Key Investors:**
- **Revenue (ARR):**
- **Employee Count:**

### 1.2 Product Overview
- **Product Name:**
- **Product Category:**
- **Delivery Model:** (SaaS / On-prem / Hybrid)
- **Primary User Persona:**
- **Core Value Proposition:**
- **Key Differentiators:**

---

## SECTION 2 — PRODUCT STRATEGY & MARKET POSITION

### 2.1 Market Opportunity
[Analysis of TAM/SAM/SOM, geographic presence, market trends, and growth trajectory]

### 2.2 Value Proposition Strength
[Assessment of whether the product delivers measurable customer value; evidence of ROI; customer success stories]

### 2.3 Competitive Landscape
[Direct and indirect competitors, differentiation, win/loss signals, competitive moat]

### 2.4 Product-Market Fit Assessment
[Evidence of PMF: retention curves, NPS trends, organic growth, customer pull signals, cohort health]

### 2.5 Product Roadmap Quality
[Clarity of vision, sequencing, feasibility, balance of innovation vs. maintenance]

**Section 2 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 3 — PACKAGING, PRICING & REVENUE MODEL

### 3.1 Revenue Model Analysis
[Revenue streams, ARR/MRR breakdown, NRR/GRR, contract structure]

### 3.2 Pricing Strategy Assessment
[Pricing methodology, tier structure, value metric alignment, upgrade paths]

### 3.3 Go-to-Market Effectiveness
[CAC by channel, LTV:CAC ratio, sales cycle efficiency, partner ecosystem]

### 3.4 Revenue Quality
[Revenue predictability, customer concentration risk, churn trends]

**Section 3 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 4 — CUSTOMER ONBOARDING & EXPERIENCE

### 4.1 Onboarding Effectiveness
[Time-to-first-value, activation rate, completion rate, drop-off analysis]

### 4.2 Customer Success Maturity
[CS team structure, health scoring, QBR cadence, churn risk management]

### 4.3 Support Quality
[Tier structure, SLAs, self-service maturity, satisfaction scores]

**Section 4 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 5 — TECHNICAL ARCHITECTURE

### 5.1 Architecture Overview
[Summary of conceptual and system architecture, key design decisions]

### 5.2 Scalability & Performance
[Multi-tenancy design, auto-scaling, throughput, latency characteristics]

### 5.3 Infrastructure & Cloud Strategy
[Cloud provider(s), IaC maturity, cost management, multi-cloud considerations]

### 5.4 Data Architecture
[Storage strategy, databases, data pipeline, analytics capabilities]

### 5.5 Authentication & Authorization
[AuthN/AuthZ maturity, protocol support, token management, IAM architecture]

### 5.6 Technical Debt Assessment
[Estimated burden: High / Medium / Low; specific areas of concern; re-architecture risk within 24 months]

### 5.7 Architecture Risks & Time Bombs
[Specific architectural decisions that will constrain future scale or require costly remediation]

**Section 5 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 6 — APPLICATION SECURITY

### 6.1 Security Posture
[Overall AppSec maturity; OWASP compliance; SAST/DAST tools; pentest cadence]

### 6.2 Data Protection
[Encryption at rest and in-flight; certificate management; data protection on client devices]

### 6.3 Compliance & Certifications
[SOC 2, ISO 27001, PCI-DSS, HIPAA, GDPR, CCPA status and gaps]

### 6.4 Incident Response Readiness
[IR plan maturity; tabletop exercises; patch management SLA; threat analytics]

### 6.5 Vulnerability & Dependency Management
[Dependency scanning cadence; known CVE exposure; secrets management]

**Section 6 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 7 — AI & MACHINE LEARNING CAPABILITIES

### 7.1 Current AI Capabilities
[ML algorithms in production; AI features shipped; GenAI/LLM usage]

### 7.2 AI Architecture & Infrastructure
[Training environment; serving infrastructure; model versioning; data flywheel]

### 7.3 AI Differentiation & Moat
[Proprietary data advantages; algorithmic differentiation vs. commoditized AI]

### 7.4 AI Strategy & Roadmap
[Strategic AI bets; AI governance; responsible AI policies; 2–3 year readiness]

**Section 7 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 8 — ENGINEERING OPERATIONS & DEVOPS

### 8.1 Development Velocity & Practices
[Release cadence; CI/CD maturity; development methodology; code quality indicators]

### 8.2 Reliability & SRE Maturity
[Actual vs. target SLA; BCDR; RPO/RTO; incident response; health dashboard]

### 8.3 Engineering Cost Structure
[Total infrastructure cost; cost per tenant; labor cost; cost optimization initiatives]

**Section 8 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 9 — CODE REPOSITORY ANALYSIS
*(Only populated when GitHub repo URL or local repo folder is provided)*

### 9.1 Repository Summary
- **Primary Languages:**
- **Repo Age:**
- **Active Contributors:**
- **Commit Frequency (last 90 days):**
- **Test Coverage:**
- **CI/CD:** Configured Y/N

### 9.2 Code Health Indicators
[Dependency freshness; known CVEs found; code duplication; linting/static analysis setup; documentation quality]

### 9.3 Security Scan Results
[Hardcoded secrets scan results; vulnerable dependency findings; security anti-patterns]

### 9.4 Engineering Velocity Signals
[Commit distribution; bus factor; PR cadence; contributor concentration]

### 9.5 Code Quality Verdict
[Overall code quality rating with specific evidence]

**Section 9 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 10 — BUSINESS LEADERSHIP & ORGANIZATION

### 10.1 Leadership Team Assessment
[CEO/CTO/CPO/CFO/CISO profiles; tenure; technical depth; completeness]

### 10.2 Financial Health
[Revenue growth rate; gross margin; burn rate and runway; path to profitability]

### 10.3 Team & Culture
[Engineering team structure; key-person risks; hiring velocity; retention signals]

**Section 10 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 11 — THIRD-PARTY DEPENDENCIES

### 11.1 Dependency Risk Assessment
[Critical third-party components; vendor lock-in risk; open-source license risk]

### 11.2 Partner Ecosystem
[Integration maturity; strategic alliances; channel partner strength]

**Section 11 Score:** ___/5
**Key Finding:** 
**Risk Items:**

---

## SECTION 12 — STRATEGIC CPTO SYNTHESIS

### 12.1 Product-Led Growth Potential
[Assessment of PLG signals: viral loops, product stickiness, self-serve expansion]

### 12.2 Platform Potential
[Can the product evolve into a platform? API ecosystem maturity; extensibility]

### 12.3 Innovation Capacity
[R&D investment %; idea-to-ship velocity; product culture; innovation pipeline]

### 12.4 Integration & Acquisition Readiness
*(If M&A context)*
[API maturity; data portability; technical integration complexity; estimated cost and timeline]

### 12.5 Strategic Risk Register

| Risk | Probability | Impact | Mitigant |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

---

## APPENDIX A — DATA SOURCES USED

| Source Type | Details |
|---|---|
| Web Research | [URLs / search queries used] |
| SEC Filings | [Filing types reviewed] |
| GitHub Repo | [Repo URL] |
| Local Repo | [Folder path] |
| Uploaded Documents | [File names] |
| User Reviews | [Sources: G2, Capterra, App Store, etc.] |
| Partner Reviews | [Sources] |

---

## APPENDIX B — INDUSTRY BENCHMARKS APPLIED

**For Technology/SaaS:**
- Revenue growth: 30–85% annually (stage-dependent)
- Gross margin: 75–85%
- Net Revenue Retention: 110–120%
- CAC payback: 12–18 months

**Scoring Scale:**
- 5 = Best-in-class, clear strength
- 4 = Above average, minor gaps
- 3 = Meets expectations, some areas to watch
- 2 = Below average, requires attention
- 1 = Significant concern, potential deal risk

**Risk Tiers:**
- 80–100 pts → Low Risk → Recommend
- 60–79 pts → Medium Risk → Conditional
- 40–59 pts → High Risk → Caution
- 0–39 pts → Critical Risk → Do Not Proceed

---

*End of Due Diligence Report*
