# CPTO Due Diligence Master Questionnaire Template
*Consolidated from Product M&A Questionnaire + CTO's Complete Due Diligence Guide*
*Focus: Product-first, with strategic + tactical coverage for CPTO evaluation*

---

## PART 1 — PRODUCT STRATEGY & MARKET POSITION

### 1.1 User & Market
- Who is the primary user? (Consumer/Enterprise, demographics, persona)
- Which geography has the strongest product presence?
- In a typical day-in-the-life of the persona, when does the user feel the need to use the product?
- Who buys the product? (Decision maker vs. user)
- TAM / SAM / SOM with methodology and data sources
- Geographic revenue breakdown and growth projections
- Typical customer journey: trigger → evaluation → adoption
- Evaluation cycle length and key decision criteria

### 1.2 Value Proposition & Competitive Position
- What specific business outcomes does the product deliver? (Quantifiable + qualitative)
- What problem does the software solve for users? How does it save time?
- Top 3–5 use cases and their revenue contribution
- Primary and indirect competitors; how the product differentiates
- Win/loss analysis methodology
- ROI calculations and payback period

### 1.3 Product Analytics & Performance
- Analytics and telemetry collected (tools, metrics: DAU/MAU, retention, engagement)
- Time-to-first-value (TTFV): from sign-up to first glimpse of value
- NPS / CSAT / CES scores
- Churn rate and retention cohort analysis
- Global user base size and growth trajectory
- Product roadmap: does one exist? What are the themes?

---

## PART 2 — PACKAGING, PRICING & GO-TO-MARKET

### 2.1 Awareness & Acquisition
- How do users become aware of the product? (Ad, WOM, partner, SEO, etc.)
- Lead generation sources and MQL → SQL conversion rates
- Sales cycle length and win rates
- Content marketing and thought leadership strategy
- CAC and LTV by channel

### 2.2 Packaging & Delivery
- How is the product packaged and delivered? (SaaS, managed service, on-prem, hybrid)
- Multi-tenant SaaS or single-tenant? How is multi-tenancy handled?
- SLA commitments: uptime, performance, support response times
- Customization and configuration options

### 2.3 Pricing & Revenue Model
- How does the product make money? (Subscription, usage, advertising, partner ecosystem)
- Pricing methodology: value-based, cost-plus, competitive
- Pricing tiers, most popular plan, highest revenue plan
- Pricing levers (per-user, per-transaction, data volume, etc.)
- Entitlements per pricing plan
- Self-service upgrade capability; how does user pay for upgrades?
- Bundle offerings; enterprise vs. SMB pricing strategies
- Is the product "price-aware"? (Does code enforce pricing plan entitlements?)
- Does the product recommend upgrades from within?

### 2.4 Revenue Operations & Metrics
- ARR / MRR; NRR / GRR
- ACV and contract term structures
- Multi-year deal incentives; renewal and expansion strategies
- Discount analysis and pricing A/B testing

---

## PART 3 — CUSTOMER ONBOARDING & EXPERIENCE

### 3.1 Onboarding
- Full onboarding workflow: contract/sign-up → first use
- Onboarding success metrics: time-to-activation, completion rate, drop-off points
- Customer success management and health scoring
- Off-boarding process: data export, contract termination, exit feedback

### 3.2 Support & Success
- Support tier structure (L1/L2/L3) and escalation procedures
- Self-service resources (knowledge base, community, docs)
- Support SLAs by customer tier
- Customer satisfaction during onboarding and ongoing
- Regular business reviews and customer advocacy programs

---

## PART 4 — TECHNICAL ARCHITECTURE & INFRASTRUCTURE

### 4.1 System Architecture
- End-to-end conceptual and system architecture (request diagram)
- Top 3 quality attributes: Availability, Security, Performance, Scalability, Usability
- Microservices vs. monolith; service decomposition rationale
- Multi-tenancy: isolation strategy (DB, compute, network), resource sharing
- Architecture roadmap

### 4.2 Client Software
- Client stack and primary delivery mechanism (AppStore, SaaS, download, etc.)
- Sign-in mechanism; session maintenance across requests
- Client-server communication: protocol, API locations, encryption
- Global distribution: same endpoint or geo-distributed? Routing strategy
- How chatty is the client? How is client health monitored?
- Client upgrade mechanism and frequency

### 4.3 Authentication & Authorization
- Authentication mechanism and supported providers
- AuthN workflow/orchestration; external/partner authentication support
- Authorization protocol (SAML, OAuth, OIDC); token type and size
- RBAC vs. ABAC; fine-grained permissions model
- Is authorization evaluated at every entry/exit point?
- How is authZ context passed between internal components?
- Third-party authorization systems used; how are privileges managed?
- AuthN/AuthZ health monitoring

### 4.4 Infrastructure & Cloud
- Cloud provider(s); IaC tools and practices
- Compute: Bare Metal / VM / Docker / Kubernetes / Serverless
- Number of compute units (microservices/VMs); cost of compute infrastructure
- Utilization by compute service; min/max cross-compute hops
- Compute geographic organization; auto-scaling policies

### 4.5 Storage & Databases
- Storage services used and their purpose; utilization and cost breakdown
- Data storage vs. transactions vs. transfer/throughput cost split
- Geo-distributed storage; synchronization strategy; SLA
- Data retention policy per tenant; low-cost archival (e.g., Glacier)
- Databases used; decision rationale for each; cost per DB
- Backup and restore policy; geo-distribution and sync per DB
- Database availability architecture; database tiers

### 4.6 Networking
- Full network architecture; cost breakdown
- Network devices: firewalls, routers, software-defined networking
- VPC usage; CDN usage and data types cached
- Network acceleration; average utilization; SLA; health monitoring

### 4.7 Web Servers & Caching
- Web server type; stateless or stateful; sticky sessions
- SSL termination point; load balancing; total cluster cost
- Auto-scaling (up and down) strategy; health monitoring
- Caching service used; object types cached; cache update strategy; cost; partitioning

### 4.8 Data Management & Analytics
- Data pipeline: source → processing → destination (flow diagram)
- Message bus/streaming product; Big Data system (Hadoop, Spark, etc.)
- Polyglot persistence strategy; analytics and BI capabilities embedded in product
- Data privacy: classification, sensitivity labeling, retention, deletion policies

### 4.9 Search & Graph Database
- Search engine used (purpose, indexes, sharding, clustering, security, backup)
- Search relevancy design; third-party plugins; query response time
- Graph database (if any): nodes, edges, query language, scale-out strategy

---

## PART 5 — APPLICATION SECURITY & RISK MANAGEMENT

### 5.1 Data Security
- Encryption at rest and in-flight mechanisms
- Certificate management: CA-signed vs. self-signed; renewal workflow
- Is all HTTP over SSL? External and internal?
- How is data protected on client devices?
- Secure Software Development Methodology followed

### 5.2 Application Security (AppSec)
- OWASP Top 10 mitigation approach
- Static/dynamic application security testing (SAST/DAST) tools
- Penetration testing cadence and remediation tracking
- Secrets management (API keys, credentials, tokens)
- Dependency vulnerability scanning and patching SLA
- Security incident response plan and tabletop exercise cadence
- Bug bounty program

### 5.3 Compliance & Certifications
- Compliance certifications: SOC 2, ISO 27001, PCI-DSS, HIPAA, GDPR, etc.
- Datacenter certifications
- Data residency requirements by geography
- Regulatory compliance by region; GDPR/CCPA controls
- Audit logging and access monitoring capabilities

---

## PART 6 — AI & MACHINE LEARNING CAPABILITIES

### 6.1 Core Algorithms & ML
- ML algorithms built within the product (list with purpose)
- Programming language used during research phase
- Process from algorithm development to production deployment
- Time from algorithm development to production
- Algorithms operationalized (list with purpose and status)

### 6.2 AI Architecture
- AI/ML infrastructure: training environment, serving infrastructure
- Model versioning and lifecycle management
- Bias detection and fairness evaluation processes
- AI feature differentiation vs. competitors
- Generative AI / LLM usage: purpose, models used, prompt management
- AI cost structure and unit economics

### 6.3 AI Strategy & Roadmap
- Strategic AI bets: what is the "AI moat"?
- AI readiness for the next 2–3 years
- AI governance and responsible AI policies
- Data flywheel: does product usage generate proprietary training data?

---

## PART 7 — BUSINESS LEADERSHIP & OPERATIONS

### 7.1 Leadership Team
- CEO, CTO, CPO, CFO, CISO profiles and tenure
- Leadership team completeness and key open roles
- Technical founder(s) still involved?
- Board composition and investor profile
- Culture and team retention metrics

### 7.2 Financial Performance
- Revenue: ARR, MRR growth rate
- Gross margin (benchmark: 75–85% for SaaS)
- Burn rate and runway
- Unit economics: CAC payback period (benchmark: 12–18 months for SaaS)
- EBITDA / path to profitability
- Fundraising history and cap table summary

### 7.3 People & Organization
- Engineering team size and structure
- Engineering / Product / Design ratio
- Key-person dependency risks
- Contractor vs. FTE ratio
- Hiring velocity and open headcount

---

## PART 8 — ENGINEERING OPERATIONS & DEVOPS

### 8.1 Software Development & Release
- Release frequency to production
- Software release methodology: DevOps, CI/CD pipelines
- Software development methodology: Agile, Kanban, etc.
- Server-side programming stack; number of languages/runtimes
- Internationalization support; accessibility support
- Blue/Green environments; A/B testing capability
- Code rollback strategy for blocking releases

### 8.2 Reliability & SLA
- Target availability SLA vs. actual availability
- Service Health Dashboard availability
- Code consistency management across tenants in managed service
- Number of tenant-specific environments; cost per tenant environment
- Recovery Point Objective (RPO) and Recovery Time Objective (RTO)
- Business Continuity and Disaster Recovery (BCDR) process
- Number of datacenters; version consistency management

### 8.3 Incident Response & Patch Management
- Software patch management strategy
- Time from published vulnerability to production patch (per stage)
- Threat analytics tools used in datacenters
- Incident response tools, processes, and workflows
- Security event protocol in datacenter

### 8.4 Cost of Operations
- Total cost of operations
- Total cost of system operations (infrastructure)
- Total cost of labor

### 8.5 Management Tools
- Systems management tools and their purpose and cost
- Management portal exposed to end-users: who uses it and for what?
- Reporting capabilities per tool

---

## PART 9 — THIRD-PARTY DEPENDENCIES & COMPLIANCE

### 9.1 Third-Party Components
- Complete list of all third-party components with: purpose, cost, decision rationale
- Open-source components and license risk assessment
- Vendor lock-in risk; alternatives available

### 9.2 Partner Ecosystem
- Technology partners and integrations
- Channel and reseller partners
- Strategic alliances and co-sell agreements
- Partner dependency risks

---

## PART 10 — CODE REPOSITORY ANALYSIS *(when repo is provided)*

### 10.1 Code Quality & Health
- Languages and frameworks used; repo structure
- Test coverage percentage
- CI/CD pipeline configuration and pipeline pass rate
- Dependency freshness (outdated packages, known CVEs)
- Code duplication and technical debt indicators
- Linting and static analysis configuration
- README and documentation quality

### 10.2 Security in Code
- Hardcoded secrets or credentials scan
- Known vulnerable dependencies (npm audit, pip-audit, etc.)
- Security-relevant patterns: input validation, SQL injection risk, XSS risk

### 10.3 Engineering Velocity
- Commit frequency and contributor distribution
- PR merge cadence; review patterns
- Issue/bug tracker integration signals (if visible)
- Bus factor: how many contributors own >80% of commits?

---

## PART 11 — STRATEGIC CPTO ASSESSMENT *(synthesized judgment layer)*

### 11.1 Product-Market Fit Signal
- Evidence of PMF: retention curves, NPS, organic growth, customer pull
- Leading vs. lagging indicators of PMF
- Cohort analysis health

### 11.2 Technical Debt & Build Quality
- Estimated technical debt burden (High / Medium / Low)
- Architectural decisions that will constrain scale
- "Time bombs": areas that will require major re-architecture within 18–24 months

### 11.3 Innovation Capacity
- R&D investment as % of revenue
- Time from idea to shipped feature (velocity)
- Quality of product roadmap: vision clarity, sequencing, feasibility

### 11.4 Strategic Risk Register
- Key risks: technology, market, team, regulatory, competitive
- Mitigants for each risk
- Deal-breaker flags (if any)

### 11.5 Integration & Acquisition Readiness (if M&A context)
- API and integration maturity
- Data portability and migration feasibility
- Cultural and technical integration complexity estimate
- Estimated integration cost and timeline

### 11.6 Overall CPTO Verdict
- Score per dimension (1–5): Product, Tech, Security, Team, AI, Operations
- Weighted overall score and risk tier (Low / Medium / High / Critical)
- Top 3 strengths
- Top 3 concerns
- Recommendation: Proceed / Proceed with conditions / Do not proceed
