---
name: cpto-due-diligence
description: >
  CPTO-level due diligence skill for evaluating companies, products, and engineering organizations.
  Use this skill whenever someone asks for due diligence, M&A assessment, acquisition analysis,
  technical evaluation, product assessment, investment diligence, or vendor evaluation of a company
  or product. Triggers on phrases like: "do due diligence on", "evaluate this company", "assess
  this product", "run a DD on", "tech diligence", "product diligence", "should we acquire",
  "partner assessment", "vendor evaluation", "analyze this GitHub repo for diligence", or when
  someone provides a company name + product + any combination of documents, SEC filings, GitHub
  URLs, or local repo paths for evaluation. This skill conducts deep internet research, repo
  analysis, and financial/product/technical assessment, then produces a complete structured CPTO
  Due Diligence Report covering strategy, product-market fit, architecture, security, AI, team,
  and operations — with both strategic and tactical findings.
---

# CPTO Due Diligence Skill

A comprehensive skill for conducting Chief Product & Technology Officer (CPTO) level due diligence on companies, products, and engineering organizations. It synthesizes online research, document analysis, financial data, user reviews, partner signals, and code repository analysis into a structured, scored report.

## When This Skill Activates

Use this skill for any of these scenarios:
- M&A technical and product due diligence
- Investment diligence (Series A–growth, PE)
- Strategic partnership or vendor evaluation
- Internal product/tech audit
- Competitive product teardown
- "Should we build vs. buy vs. partner?" decisions

## Inputs the Skill Accepts

The user may provide any combination of:

1. **Company name + product name** (minimum required)
2. **Reference documents** — uploaded files (PDFs, Word docs, spreadsheets), web page URLs, SEC filings, investor decks
3. **GitHub repo URL** — e.g. `https://github.com/org/repo`
4. **Local repo folder path** — e.g. `/home/user/projects/target-company`

## Step-by-Step Workflow

### STEP 0 — Gather Inputs
At the start, confirm what has been provided:
- Company name and product name
- Any uploaded files (check `/mnt/user-data/uploads/`)
- GitHub repo URL or local folder path
- Assessment context (M&A / investment / partnership / audit)

If only a company name is given, proceed with web research as the primary source. Tell the user what you're about to do.

---

### STEP 1 — Read the Questionnaire Template

**Before doing any research**, read the full questionnaire template at:
`references/DD_QUESTIONNAIRE_TEMPLATE.md`

This is the backbone of the DD report. Every section of the report maps to questions in this template. Keep it as a mental checklist as you gather data.

---

### STEP 2 — Document Ingestion

If documents, URLs, or SEC filings were provided:
- Read uploaded files using the file-reading skill or `extract-text` for .docx
- Fetch web pages using `web_fetch`
- For SEC filings: identify key financials (ARR, revenue growth, gross margin, burn rate, headcount) and product mentions
- Extract key signals: financials, product descriptions, risk factors, customer metrics

Organize extracted facts by questionnaire section (Product / Tech / Business / AI / Operations).

---

### STEP 3 — Web Research (Always Run)

Conduct a systematic internet research sweep regardless of whether documents were provided. Use `web_search` for each of the following:

**Company Research:**
```
[Company Name] company overview funding ARR employees
[Company Name] product reviews G2 Capterra Trustpilot
[Company Name] SEC filing OR 10-K OR S-1 OR funding announcement
[Company Name] engineering blog OR tech stack OR architecture
[Company Name] competitors comparison
[Company Name] leadership team CTO CPO CEO
[Company Name] news site:techcrunch.com OR site:venturebeat.com
```

**Product Research:**
```
[Product Name] user reviews
[Product Name] vs [Competitor] comparison
[Product Name] pricing plans
[Product Name] API documentation
[Product Name] NPS OR customer satisfaction
[Product Name] case studies OR customer stories
```

**Partner & Ecosystem Research:**
```
[Company Name] partner integrations
[Company Name] marketplace OR app store OR ecosystem
[Company Name] channel partners OR resellers
```

Synthesize research findings into structured notes per DD section. Always cite your sources.

---

### STEP 4 — Repository Analysis (When Provided)

If a GitHub URL or local folder was provided, run the repo analyzer:

**For GitHub URL:**
```bash
python scripts/repo_analyzer.py --github [URL] --clone-to /tmp/dd_repo
```

**For local folder:**
```bash
python scripts/repo_analyzer.py --path [FOLDER_PATH]
```

Parse the JSON output and use it to populate Section 9 (Code Repository Analysis) of the report.

Additionally, perform manual inspection of:
- `README.md` for architecture description and setup quality
- CI/CD workflow files (`.github/workflows/`, `.gitlab-ci.yml`)
- `package.json` / `requirements.txt` / `go.mod` for dependency health
- Key source directories for code organization and patterns
- Test directory structure and coverage tooling

---

### STEP 5 — Financial & Metrics Analysis

Compile financial and operational metrics from all sources:

**Key metrics to find or estimate:**
- ARR / MRR (and growth rate YoY)
- Gross margin (benchmark: 75–85% for SaaS)
- Net Revenue Retention (benchmark: >110%)
- CAC payback period (benchmark: 12–18 months)
- Burn rate and runway
- Employee count and engineering headcount

If precise figures aren't available publicly, note this and provide reasonable estimates with confidence levels (High / Medium / Low confidence).

---

### STEP 6 — User & Partner Review Synthesis

Search and synthesize:
- G2, Capterra, Trustpilot, App Store, Play Store reviews
- Industry analyst mentions (Gartner, Forrester, IDC)
- Reddit, Hacker News product discussions
- LinkedIn company reviews (Glassdoor for team culture signals)
- Partner ecosystem testimonials

Extract: sentiment trends, top praised features, top complaints, NPS signals, churn indicators.

---

### STEP 7 — Generate the Report

**Read the report template first:**
`references/REPORT_TEMPLATE.md`

Use this template to structure the output. Follow the template exactly — fill in every section. For sections where data is unavailable, state "Insufficient data available — recommend requesting from target during management interviews" rather than leaving blanks.

**Scoring guidance:**
- Score each section 1–5 based on evidence quality and benchmarks
- Apply the industry benchmarks from `references/REPORT_TEMPLATE.md` Appendix B
- Compute weighted overall score
- Assign risk tier: Low / Medium / High / Critical

**Writing style for the report:**
- Lead with the strategic insight before the tactical detail
- Be opinionated — this is a CPTO assessment, not a neutral summary
- Quantify wherever possible; call out when data is estimated
- Flag "deal-breaker" issues explicitly in red-flag language
- Distinguish between structural risks (hard to fix) and operational gaps (fixable)

**Output format:** Generate the report as a `.md` file saved to `/mnt/user-data/outputs/[CompanyName]_CPTO_DD_Report_[Date].md`. Also offer to create a `.docx` version.

---

## Reference Files

| File | Purpose | When to Read |
|---|---|---|
| `references/DD_QUESTIONNAIRE_TEMPLATE.md` | Master list of all DD questions (consolidated from both source documents) | STEP 1 — always |
| `references/REPORT_TEMPLATE.md` | Output report structure with scoring rubrics and benchmarks | STEP 7 — when generating report |
| `scripts/repo_analyzer.py` | Automated code repo analysis script | STEP 4 — when repo is provided |

---

## Quality Standards

A good CPTO DD report:
- **Is evidence-based** — every rating is backed by specific findings, not opinion
- **Is product-first** — the product section is the longest and most detailed
- **Has strategic AND tactical depth** — executives get the headline; engineers get the detail
- **Is honest about gaps** — "we couldn't find data on X; recommend requesting" is better than speculation
- **Gives a clear verdict** — don't hedge the recommendation; make the call

---

## Example Invocations

```
Do a full CPTO due diligence on Acme Corp, their product is called AcmeFlow. 
Here's their pitch deck [upload], and their GitHub is https://github.com/acmecorp/acmeflow.
```

```
Run a product and tech DD on Datadog for a potential partnership. Focus on their 
AI roadmap and pricing model.
```

```
Analyze this repo for due diligence: /home/projects/target-startup
The company is NovaSoft and the product is NovaAnalytics.
```

```
I'm evaluating whether to acquire StartupXYZ. Here are their SEC S-1 filing [upload] 
and product questionnaire responses [upload]. Give me a full CPTO assessment.
```
