#!/usr/bin/env python3
"""
CPTO Due Diligence — Repository Analyzer
Analyzes a GitHub repo (cloned) or local repo folder and outputs
a structured JSON report for inclusion in the DD report.

Usage:
  python repo_analyzer.py --path /path/to/repo
  python repo_analyzer.py --github https://github.com/org/repo --clone-to /tmp/repo
"""

import os
import sys
import json
import subprocess
import argparse
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timedelta

def run(cmd, cwd=None, capture=True):
    try:
        result = subprocess.run(
            cmd, shell=True, cwd=cwd,
            capture_output=capture, text=True, timeout=60
        )
        return result.stdout.strip(), result.returncode
    except Exception as e:
        return str(e), 1

def clone_repo(url, dest):
    print(f"Cloning {url} → {dest}")
    out, code = run(f"git clone --depth 100 {url} {dest}")
    return code == 0

def detect_languages(repo_path):
    """Count lines by file extension as a language proxy."""
    ext_map = {
        '.py': 'Python', '.js': 'JavaScript', '.ts': 'TypeScript',
        '.jsx': 'React/JSX', '.tsx': 'React/TSX', '.go': 'Go',
        '.java': 'Java', '.kt': 'Kotlin', '.rb': 'Ruby',
        '.rs': 'Rust', '.cs': 'C#', '.cpp': 'C++', '.c': 'C',
        '.swift': 'Swift', '.php': 'PHP', '.scala': 'Scala',
        '.html': 'HTML', '.css': 'CSS', '.scss': 'SCSS',
        '.yaml': 'YAML', '.json': 'JSON', '.sh': 'Shell',
        '.sql': 'SQL',
    }
    counts = Counter()
    skip_dirs = {'node_modules', '.git', 'vendor', 'dist', 'build', '__pycache__', '.venv', 'venv'}

    for root, dirs, files in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for f in files:
            ext = Path(f).suffix.lower()
            if ext in ext_map:
                counts[ext_map[ext]] += 1
    return dict(counts.most_common(8))

def get_git_stats(repo_path):
    """Extract git commit statistics."""
    stats = {}

    # Total commits
    out, _ = run("git log --oneline | wc -l", cwd=repo_path)
    stats['total_commits'] = out.strip()

    # Commits last 90 days
    since = (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d')
    out, _ = run(f"git log --oneline --after={since} | wc -l", cwd=repo_path)
    stats['commits_last_90_days'] = out.strip()

    # Contributors (all time)
    out, _ = run("git log --format='%ae' | sort -u | wc -l", cwd=repo_path)
    stats['unique_contributors'] = out.strip()

    # Bus factor: who owns >80% of commits
    out, _ = run("git log --format='%ae' | sort | uniq -c | sort -rn | head -5", cwd=repo_path)
    stats['top_contributors'] = out.strip()

    # Repo age
    out, _ = run("git log --reverse --format='%ad' --date=short | head -1", cwd=repo_path)
    stats['first_commit_date'] = out.strip()

    # Latest commit
    out, _ = run("git log -1 --format='%ad' --date=short", cwd=repo_path)
    stats['latest_commit_date'] = out.strip()

    # Open branches
    out, _ = run("git branch -r | wc -l", cwd=repo_path)
    stats['remote_branches'] = out.strip()

    return stats

def detect_ci_cd(repo_path):
    """Check for CI/CD configuration files."""
    ci_files = {
        '.github/workflows': 'GitHub Actions',
        '.gitlab-ci.yml': 'GitLab CI',
        'Jenkinsfile': 'Jenkins',
        '.circleci/config.yml': 'CircleCI',
        '.travis.yml': 'Travis CI',
        'azure-pipelines.yml': 'Azure Pipelines',
        'bitbucket-pipelines.yml': 'Bitbucket Pipelines',
        'Dockerfile': 'Docker',
        'docker-compose.yml': 'Docker Compose',
        'k8s': 'Kubernetes',
        'kubernetes': 'Kubernetes',
        'helm': 'Helm',
        '.terraform': 'Terraform',
        'terraform': 'Terraform',
    }
    found = []
    for path_fragment, label in ci_files.items():
        full = os.path.join(repo_path, path_fragment)
        if os.path.exists(full) and label not in found:
            found.append(label)
    return found

def detect_test_setup(repo_path):
    """Look for test configuration and estimate coverage signals."""
    test_signals = {
        'test_dirs': [],
        'test_frameworks': [],
        'coverage_config': False,
    }
    test_dir_names = {'test', 'tests', 'spec', 'specs', '__tests__', 'test_suite'}
    test_frameworks = {
        'pytest': 'pytest.ini|setup.cfg|pyproject.toml',
        'jest': 'jest.config.js|jest.config.ts|package.json',
        'mocha': '.mocharc|mocha.opts',
        'rspec': '.rspec|spec',
        'junit': 'build.gradle|pom.xml',
        'go test': '_test.go',
        'cargo test': 'Cargo.toml',
    }
    coverage_files = ['.coveragerc', 'coverage.xml', 'lcov.info', '.nycrc', 'jacoco.xml']

    for root, dirs, files in os.walk(repo_path):
        for d in dirs:
            if d.lower() in test_dir_names:
                rel = os.path.relpath(os.path.join(root, d), repo_path)
                if rel not in test_signals['test_dirs']:
                    test_signals['test_dirs'].append(rel)

    for cov_file in coverage_files:
        out, _ = run(f"find {repo_path} -name '{cov_file}' | head -1")
        if out:
            test_signals['coverage_config'] = True
            break

    return test_signals

def security_scan(repo_path):
    """Basic security signal detection."""
    findings = {
        'hardcoded_secrets_signals': [],
        'vulnerable_deps': [],
        'security_config_found': [],
    }

    # Look for common secret patterns (rough heuristic)
    secret_patterns = [
        'password\s*=\s*["\'][^"\']+["\']',
        'api_key\s*=\s*["\'][^"\']+["\']',
        'secret\s*=\s*["\'][^"\']+["\']',
        'AWS_SECRET',
        'PRIVATE_KEY',
    ]
    for pattern in secret_patterns:
        out, code = run(
            f"grep -rn --include='*.py' --include='*.js' --include='*.ts' --include='*.env' "
            f"-i '{pattern}' {repo_path} | grep -v '.git' | head -3"
        )
        if out and code == 0:
            findings['hardcoded_secrets_signals'].append(f"Pattern '{pattern}': {out[:200]}")

    # npm audit (if package.json exists)
    if os.path.exists(os.path.join(repo_path, 'package.json')):
        out, code = run("npm audit --json 2>/dev/null | python3 -c \"import sys,json; d=json.load(sys.stdin); print(f'vulnerabilities: {d.get(\\\"metadata\\\",{}).get(\\\"vulnerabilities\\\",{})}')\" ", cwd=repo_path)
        if out:
            findings['vulnerable_deps'].append(f"npm: {out}")

    # pip-audit or safety (if requirements.txt)
    req_files = ['requirements.txt', 'requirements.in', 'Pipfile']
    for rf in req_files:
        if os.path.exists(os.path.join(repo_path, rf)):
            out, code = run(f"pip-audit -r {rf} --format json 2>/dev/null | head -5", cwd=repo_path)
            if out and code != 0:
                findings['vulnerable_deps'].append(f"pip-audit: see output")

    # Security config files
    security_configs = ['.snyk', '.semgrep.yml', 'SECURITY.md', '.github/SECURITY.md', 'trivy.yaml']
    for sc in security_configs:
        if os.path.exists(os.path.join(repo_path, sc)):
            findings['security_config_found'].append(sc)

    return findings

def check_documentation(repo_path):
    """Check documentation quality signals."""
    doc_signals = {}
    doc_files = ['README.md', 'README.rst', 'README.txt', 'CONTRIBUTING.md',
                 'CHANGELOG.md', 'docs/', 'wiki/', 'API.md', 'ARCHITECTURE.md']
    for df in doc_files:
        exists = os.path.exists(os.path.join(repo_path, df))
        doc_signals[df] = exists
    return doc_signals

def check_linting(repo_path):
    """Look for linting and formatting configuration."""
    lint_configs = {
        '.eslintrc*': 'ESLint',
        '.prettierrc*': 'Prettier',
        'pyproject.toml': 'Python (check for black/ruff)',
        '.flake8': 'Flake8',
        '.rubocop.yml': 'RuboCop',
        'golangci.yml': 'golangci-lint',
        '.editorconfig': 'EditorConfig',
    }
    found = []
    for pattern, label in lint_configs.items():
        out, _ = run(f"find {repo_path} -maxdepth 2 -name '{pattern}' | head -1")
        if out:
            found.append(label)
    return found

def main():
    parser = argparse.ArgumentParser(description='CPTO DD Repo Analyzer')
    parser.add_argument('--path', help='Path to local repo')
    parser.add_argument('--github', help='GitHub URL to clone')
    parser.add_argument('--clone-to', default='/tmp/dd_repo_clone', help='Where to clone the repo')
    args = parser.parse_args()

    repo_path = args.path
    if args.github:
        dest = args.clone_to
        if not clone_repo(args.github, dest):
            print(json.dumps({'error': f'Failed to clone {args.github}'}))
            sys.exit(1)
        repo_path = dest

    if not repo_path or not os.path.exists(repo_path):
        print(json.dumps({'error': 'No valid repo path provided'}))
        sys.exit(1)

    print(f"Analyzing repo at: {repo_path}", file=sys.stderr)

    report = {
        'repo_path': repo_path,
        'analysis_timestamp': datetime.now().isoformat(),
        'languages': detect_languages(repo_path),
        'git_stats': get_git_stats(repo_path),
        'ci_cd': detect_ci_cd(repo_path),
        'test_setup': detect_test_setup(repo_path),
        'security': security_scan(repo_path),
        'documentation': check_documentation(repo_path),
        'linting': check_linting(repo_path),
    }

    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
